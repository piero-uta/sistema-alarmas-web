<?php $__env->startSection('title', 'Direcciones'); ?>

<?php $__env->startSection('content'); ?>

<h2>Direcciones</h2>
<div>
    <table class="table">
        <thead>
            <tr>
                <th scope="col">
                    #
                </th>
                <th scope="col">
                    Rut
                </th>
                <th scope="col">
                    Calle
                </th>
                <th scope="col">
                    Numero
                </th>
                <th scope="col">
                    Representante
                </th>
                <th scope="col">
                    Codigo
                </th>
                <th scope="col">
                    Acciones
                </th>
            </tr>            
        </thead>
        <tbody>
            <?php $__currentLoopData = $direcciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $direccion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr onClick="modalDireccion(<?php echo e($direccion); ?>)">
                <th scope="row">
                    <?php echo e($direccion->id); ?>

                </th>
                <td>
                    <?php echo e($direccion->rut); ?> - <?php echo e($direccion->digito); ?>

                </td>
                <td>
                    <?php echo e($direccion->calle); ?>

                </td>
                <td>
                    <?php echo e($direccion->numero); ?>

                </td>
                <td>
                    <?php echo e($direccion->representante); ?>

                </td>
                <td>
                    <?php echo e($direccion->codigo); ?>

                </td>
                <td>
                    <a type="button" class="btn btn-primary" href="<?php echo e(route('direcciones.crearEditar', ['id' => $direccion->id])); ?>">Editar</a>
                    
                    <form method="POST" action="<?php echo e(route('direcciones.eliminar')); ?>">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id" value="<?php echo e($direccion->id); ?>">
                        <button type="submit" class="btn btn-danger">Eliminar</button>
                    </form>
                </td>

            </tr>
                
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>

    </table>
    <div class="d-flex justify-content-end py-2">
        <a type="button" class="btn btn-primary" href="<?php echo e(route('direcciones.crearEditar')); ?>">Crear</a>
    </div>
</div>


<?php $__env->stopSection(); ?>






<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\CORE I5\Desktop\uta\webProyecto4\proyecto4\sistema-alarmas-web\resources\views/direcciones/index.blade.php ENDPATH**/ ?>