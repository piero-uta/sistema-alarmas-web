<?php $__env->startSection('title', 'Guardar comunidad'); ?>

<?php $__env->startSection('content'); ?>
<h1 class="login-page-new__main-form-title">Crear comunidad</h1>

<form method="POST" class="form form__container"action="<?php echo e(route('comunidades.handleGuardar')); ?>">
    <?php echo csrf_field(); ?>
    <?php if(isset($comunidad)): ?>
        <input type="hidden" name="id" value="<?php echo e($comunidad->id); ?>">
    <?php endif; ?>

    <div>
        <label for="rut" class="label">Rut*</label>
        <input type="number" class="input" name="rut" required
        value="<?php echo e(old('rut')==null ? ( isset($comunidad)?$comunidad->rut:'' ) : old('rut')); ?>">
    </div>
    <div >
        <label for="digito" class="label">Digito*</label>
        <input type="text" class="input" name="digito"required
        value="<?php echo e(old('digito')==null ? ( isset($comunidad)?$comunidad->digito:'' ) : old('digito')); ?>">
    </div>
    <div >
        <label for="razon_social" class="label">Razon social*</label>
        <input type="text" class="input" name="razon_social" required
        value="<?php echo e(old('razon_social')==null ? ( isset($comunidad)?$comunidad->razon_social:'' ) : old('razon_social')); ?>">
    </div>
    <div >
        <label for="representante_legal" class="label">Representante legal</label>
        <input type="text" class="input" name="representante_legal" 
        value="<?php echo e(old('representante_legal')==null ? ( isset($comunidad)?$comunidad->representante_legal:'' ) : old('representante_legal')); ?>">
    </div>
    <div >
        <label for="email" class="label">Email</label>
        <input type="email" class="input" name="email"
        value="<?php echo e(old('email')==null ? ( isset($comunidad)?$comunidad->email:'' ) : old('email')); ?>">
    </div>
    <div >
        <label for="direccion" class="label">Dirección*</label>
        <input type="text" class="input" name="direccion" required
        value="<?php echo e(old('direccion')==null ? ( isset($comunidad)?$comunidad->direccion:'' ) : old('direccion')); ?>">
    </div>
    <div >
        <label for="giro" class="label">Giro</label>
        <input type="text" class="input" name="giro" 
        value="<?php echo e(old('giro')==null ? ( isset($comunidad)?$comunidad->giro:'' ) : old('giro')); ?>">
    <div >
        <label for="tipo_servicio" class="label">Tipo servicio*</label>
        <input type="text" class="input" name="tipo_servicio" required
        value="<?php echo e(old('tipo_servicio')==null ? ( isset($comunidad)?$comunidad->tipo_servicio:'' ) : old('tipo_servicio')); ?>">
    </div>
    <div >
        <label for="costo_mensual" class="label">Costo mensual*</label>
        <input type="number" class="input" name="costo_mensual" required
        value="<?php echo e(old('costo_mensual')==null ? ( isset($comunidad)?$comunidad->costo_mensual:'' ) : old('costo_mensual')); ?>">
    </div>
    <div >
        <label for="telefono" class="label">Telefono</label>
        <input type="number" class="input" name="telefono" 
        value="<?php echo e(old('telefono')==null ? ( isset($comunidad)?$comunidad->telefono:'' ) : old('telefono')); ?>">
    </div>
    <div >
        <label for="celular" class="label">Celular</label>
        <input type="number" class="input" name="celular" 
        value="<?php echo e(old('celular')==null ? ( isset($comunidad)?$comunidad->celular:'' ) : old('celular')); ?>">
    </div>
    
    <div >
        <input class="form-check-input" type="checkbox" name="activo" id="activo" 
        <?php echo e(old('activo')==null 
            ? ( isset($comunidad) && $comunidad->activo==0 ? '' : 'checked' ) 
            : ( old('activo')==1 ? 'checked' : '' )); ?>>
        <label class="label" for="activo">
            Activo
        </label>

    </div>
    <div class="d-grid gap-2 py-2">
    <button type="submit" class="btn btn-primary">Guardar</button>
    <input type="hidden" name="id" id="id_comunidad_eliminar" required>
    <button type="submit" class="btn btn-danger" id="btn_eliminar_comunidad">Cerrar</button>
               
    </div>
</form>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\CORE I5\Desktop\uta\webProyecto4\proyecto4\sistema-alarmas-web\resources\views/comunidades/guardar.blade.php ENDPATH**/ ?>