<?php $__env->startSection('title', 'Usuarios'); ?>

<?php $__env->startSection('content'); ?>

<div>
    <?php if($comunidades): ?>
        <?php $__currentLoopData = $comunidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comunidad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div>
                
                <a href="<?php echo e(route('comunidades.seleccionar', ['comunidad_id' => $comunidad->id])); ?>">
                    <?php echo e($comunidad->razon_social); ?>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <div>
            No hay comunidades
        </div>  
    <?php endif; ?> 

    
    
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\CORE I5\Desktop\uta\webProyecto4\proyecto4\sistema-alarmas-web\resources\views/seleccionarComunidad.blade.php ENDPATH**/ ?>