<?php $__env->startSection('title', 'Login'); ?>

<?php $__env->startSection('content'); ?>

<form method="POST" action="<?php echo e(route('loginAdmin.handleLoginAdmin')); ?>">
    <?php echo csrf_field(); ?>
    <h2>Iniciar Sesión</h2>
    <div class="mb-3">
        <label for="email" class="form-label">Email*</label>
        <input type="email" class="form-control" name="email" required
        value="<?php echo e(old('email')); ?>">
    </div>
    <div class="mb-3">
        <label for="password" class="form-label">Password*</label>
        <input type="password" class="form-control" name="password" required>
    </div>
    <div class="mb-3">
        <div class="form-check ">
            <input class="form-check-input" type="checkbox" id="remember" name="remember" <?php if(old('remember')): echo 'checked'; endif; ?>>
            <label class="form-check-label" for="remember">Recordarme</label>
        </div>

    </div>
    <button type="submit" class="btn btn-primary">Iniciar Sesión</button>
    
</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\CORE I5\Desktop\uta\webProyecto4\proyecto4\sistema-alarmas-web\resources\views/autenticacion/loginAdmin.blade.php ENDPATH**/ ?>