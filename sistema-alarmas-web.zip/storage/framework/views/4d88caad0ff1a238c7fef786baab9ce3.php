<header class="header <?php if(auth()->guard()->check()): ?> header--auth <?php endif; ?>">

<div class="header__section">
        <!-- Menú hamborquesa aquí -->
        <button class="hamburguer__button">
            <i class="fas fa-bars"> aaa</i>                
        </button>
        
    </div>

</header><?php /**PATH C:\Users\CORE I5\Desktop\uta\webProyecto4\proyecto4\sistema-alarmas-web\resources\views/includes/header.blade.php ENDPATH**/ ?>