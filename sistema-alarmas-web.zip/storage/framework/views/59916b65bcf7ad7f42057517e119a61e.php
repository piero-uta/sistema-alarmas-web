<?php $__env->startSection('title', 'Guardar red de aviso'); ?>

<?php $__env->startPush('head-scripts'); ?>
    <script src="https://polyfill.io/v3/polyfill.min.js?features=default"></script>
    
    <script>
        (g=>{var h,a,k,p="The Google Maps JavaScript API",c="google",l="importLibrary",q="__ib__",m=document,b=window;b=b[c]||(b[c]={});var d=b.maps||(b.maps={}),r=new Set,e=new URLSearchParams,u=()=>h||(h=new Promise(async(f,n)=>{await (a=m.createElement("script"));e.set("libraries",[...r]+"");for(k in g)e.set(k.replace(/[A-Z]/g,t=>"_"+t[0].toLowerCase()),g[k]);e.set("callback",c+".maps."+q);a.src=`https://maps.${c}apis.com/maps/api/js?`+e;d[q]=f;a.onerror=()=>h=n(Error(p+" could not load."));a.nonce=m.querySelector("script[nonce]")?.nonce||"";m.head.append(a)}));d[l]?console.warn(p+" only loads once. Ignoring:",g):d[l]=(f,...n)=>r.add(f)&&u().then(()=>d[l](f,...n))})({
            key: "AIzaSyCJNN-iTg6exmzgXLjB_4KNGY_869oNBGM",
            v: "weekly",    
            libraries: "places",
            languaje: "es",
        });
      </script>

<?php $__env->stopPush(); ?>


<?php $__env->startSection('content'); ?>
    <h2>Crear red de aviso para <?php echo e($direccionSeleccionada->codigo); ?></h2>
    <form method="POST" class="form form__container" action="<?php echo e(route('red-avisos.handleGuardar')); ?>">
        <?php echo csrf_field(); ?>
        <?php if(isset($red)): ?>
            <input type="hidden" name="id" value="<?php echo e($red->id); ?>">
        <?php endif; ?>

        <input type="hidden" name="direccion_id" value="<?php echo e($direccionSeleccionada->id); ?>">

        <div class="form-group">
            <label for="direccion">Dirección del vecino</label>
            <select class="form-control" id="direccion" name="direccion_vecino_id">
                <option value="">Seleccionar</option>
                <?php $__currentLoopData = $direcciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $direccion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($direccion->id); ?>" <?php echo e(old('direccion_vecino_id') == null
                        ? (isset($red) && $red->direccion_vecino_id == $direccion->id
                            ? 'selected'
                            : '')
                        : (old('direccion_vecino_id') == $direccion->id
                            ? 'selected'
                            : '')); ?>><?php echo e($direccion->codigo); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        
        <div class="form-check">
            <input class="form-check-input" type="checkbox" name="activo" id="activo" 
                <?php echo e(old('activo') == null
                    ? (isset($usuario) && $usuario->activo == 0
                        ? ''
                        : 'checked')
                    : (old('activo') == 1
                        ? 'checked'
                        : '')); ?>>
            <label class="form-check-label" for="activo">
                Activo
            </label>

        </div>

        <div id="map" style="height: 400px; width: 100%; z-index: 0; margin: 3rem 0"></div>



        <div class="d-grid gap-2 py-2">
            <button type="submit" class="btn btn-primary">Guardar</button>
            <a class="btn btn-primary" href="/red-avisos">Cancelar</a>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    const direccionSeleccionada=<?php echo json_encode($direccionSeleccionada); ?>;
    const idDireccionVecinoInput = document.getElementById('direccion');
    const direccionesVecinos = <?php echo json_encode($direcciones); ?>;
    const comunidad = <?php echo json_encode($comunidad); ?>;
</script>
    <script type="text/javascript" src="<?php echo e(asset('js/redAviso/guardarMapa.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\CORE I5\Desktop\uta\webProyecto4\proyecto4\sistema-alarmas-web\resources\views/redAviso/guardar.blade.php ENDPATH**/ ?>