<div class="hamburguer__menu">

    <!-- Opciones -->
    <ul class="hamburguer__list">
        

        
        <li class="hamburguer__item">
            <a href="<?php echo e(route('usuarios.index')); ?>" class="hamburguer__item-link" title="Usuarios"><i class="hamburguer__item-icon fas fa-home"></i>usuarios</a>
        </li>

  
            <li class="hamburguer__item">
                <a class="hamburguer__item-link" href="<?php echo e(route('direcciones.index')); ?>" title="Direcciones"><i class="hamburguer__item-icon fa fa-city"></i>direcciones</a>
            </li>
 

            <li class="hamburguer__item">
                <a class="hamburguer__item-link" href="<?php echo e(route('perfiles.index')); ?>" title="Perfiles"><i class="hamburguer__item-icon fas fa-building"></i>perfiles</a>
            </li>

            <li class="hamburguer__item">
                <a class="hamburguer__item-link" href="<?php echo e(route('comunidades.index')); ?>" title="Comunidades"><i class="hamburguer__item-icon fas fa-user-tag"></i>comunidades</a>
            </li>

</div><?php /**PATH C:\Users\CORE I5\Desktop\uta\webProyecto4\proyecto4\sistema-alarmas-web\resources\views/includes/menu-hamburguesa.blade.php ENDPATH**/ ?>