<?php $__env->startSection('title', 'Login'); ?>

<?php $__env->startSection('content'); ?>
<main class="auth bg-isometrico">

<form method="POST" class="form auth__form-container pop-anim show" action="<?php echo e(route('login.handleLogin')); ?>">
    <?php echo csrf_field(); ?>
    <h2 class="login-page-new__main-form-title">Iniciar Sesión</h2>
    <div >
        <label for="email" class="label">Email*</label>
        <input type="email" class="input" name="email" required
        value="<?php echo e(old('email')); ?>">
    </div>
    <div >
        <label for="password" class="label">Password*</label>
        <input type="password" class="input" name="password" required>
    </div>
    <div class="form__container-flex mb-5">
        <div class="form-check form-switch d-flex" ">
            <input class="form-check-input" type="checkbox" id="remember" name="remember" <?php if(old('remember')): echo 'checked'; endif; ?>>
            <label class="form-check-label" for="remember">Recordarme</label>
        </div>

    </div>
    <div class="d-grid gap-2 py-2">
    <button type="submit" class="btn btn-primary">Guardar</button>
    <bu
    </div>
</form>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\CORE I5\Desktop\webProyecto4\proyecto4\sistema-alarmas-web\resources\views/autenticacion/login.blade.php ENDPATH**/ ?>