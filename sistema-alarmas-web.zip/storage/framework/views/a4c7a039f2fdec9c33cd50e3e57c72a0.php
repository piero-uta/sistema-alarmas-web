
<?php if(session('comunidad_id')): ?>
    <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">
        <!-- Sidebar - Brand -->
        <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.html">
            <img class="img-profile" width="50" src=<?php echo e(session('comunidad_logo')); ?>>

            <div class="sidebar-brand-text mx-3">Sistema de Alarmas</div>
        </a>

        <?php
            $permisos = session('permisos');
        ?>

        <!-- Nav Item - Comunidades -->
        <?php if(in_array('Comunidad-c', $permisos) ||
                in_array('Comunidad-r', $permisos) ||
                in_array('Comunidad-u', $permisos) ||
                in_array('Comunidad-d', $permisos)): ?>
            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <li class="nav-item active">
                <a class="nav-link" href="/comunidades">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Comunidades</span></a>
            </li>
        <?php endif; ?>

        <!-- Nav Item - Usuarios -->
        <?php if(in_array('Usuarios-c', $permisos) ||
                in_array('Usuarios-r', $permisos) ||
                in_array('Usuarios-u', $permisos) ||
                in_array('Usuarios-d', $permisos)): ?>
            <!-- Divider -->
            <hr class="sidebar-divider">

            <li class="nav-item active">
                <a class="nav-link" href="/usuarios">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Usuarios</span></a>
            </li>
        <?php endif; ?>


        <!-- Nav Item - Direcciones -->
        <?php if(in_array('DireccionesUsuario-c', $permisos) ||
                in_array('DireccionesUsuario-r', $permisos) ||
                in_array('DireccionesUsuario-u', $permisos) ||
                in_array('DireccionesUsuario-d', $permisos)): ?>
            <!-- Divider -->
            <hr class="sidebar-divider">

            <li class="nav-item active">
                <a class="nav-link" href="/direcciones">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Direcciones</span></a>
            </li>
        <?php endif; ?>

        <?php if(in_array('RedAviso-c', $permisos) ||
                in_array('RedAviso-r', $permisos) ||
                in_array('RedAviso-u', $permisos) ||
                in_array('RedAviso-d', $permisos)): ?>
            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Nav Item - Red de Avisos -->
            <li class="nav-item active">
                <a class="nav-link" href="/red-avisos">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Red de Avisos</span></a>
            </li>
        <?php endif; ?>

        <?php if(in_array('DashboardMonitoreo-c', $permisos) ||
                in_array('DashboardMonitoreo-r', $permisos) ||
                in_array('DashboardMonitoreo-u', $permisos) ||
                in_array('DashboardMonitoreo-d', $permisos)): ?>
            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Nav Item - Red de Avisos -->
            <li class="nav-item active">
                <a class="nav-link" href="/monitoreo">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Dashboard de Monitoreo</span></a>
            </li>
        <?php endif; ?>

        <?php if(in_array('AsignacionPerfiles-c', $permisos) ||
                in_array('AsignacionPerfiles-r', $permisos) ||
                in_array('AsignacionPerfiles-u', $permisos) ||
                in_array('AsignacionPerfiles-d', $permisos)): ?>
            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Nav Item - Red de Avisos -->
            <li class="nav-item active">
                <a class="nav-link" href="/asignacionPerfiles">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Asignacion de Perfiles</span></a>
            </li>
        <?php endif; ?>

        <?php if(in_array('Perfiles-c', $permisos) ||
                in_array('Perfiles-r', $permisos) ||
                in_array('Perfiles-u', $permisos) ||
                in_array('Perfiles-d', $permisos)): ?>
            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Nav Item - Red de Avisos -->
            <li class="nav-item active">
                <a class="nav-link" href="/perfiles">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Perfiles</span></a>
            </li>
        <?php endif; ?>

        <!-- Sidebar Toggler (Sidebar) -->
        <div class="text-center d-none d-md-inline">
            <button class="rounded-circle border-0" id="sidebarToggle"></button>
        </div>


        
    </ul>
<?php endif; ?>
<?php /**PATH C:\Users\CORE I5\Desktop\uta\webProyecto4\proyecto4\sistema-alarmas-web\resources\views/includes/navbar.blade.php ENDPATH**/ ?>