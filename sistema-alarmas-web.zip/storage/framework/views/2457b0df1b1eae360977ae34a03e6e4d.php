<?php $__env->startSection('title', 'Guardar perfil'); ?>

<?php $__env->startSection('content'); ?>
    <h2>Crear Perfil</h2>
    <form method="POST" action="<?php echo e(route('perfiles.handleGuardar')); ?>">
        <?php echo csrf_field(); ?>
        <?php if(isset($perfil)): ?>
            <input type="hidden" name="id" value="<?php echo e($perfil->id); ?>">
        <?php endif; ?>
        <div class="form-group">
            <label for="nombre" class="label">Nombre</label>
            <input type="text" class="form-control" name="nombre" required
                value="<?php echo e(old('nombre') == null ? (isset($perfil) ? $perfil->nombre : '') : old('name')); ?>">
        </div>
        <div class="form-group">
            <label for="descripcion" class="label">Descripcion</label>
            <input type="text" class="form-control" name="descripcion" required
                value="<?php echo e(old('descripcion') == null ? (isset($perfil) ? $perfil->descripcion : '') : old('descripcion')); ?>">
        </div>
        <hr>
        <div class="form-check py-2">
            <input class="form-check-input" type="checkbox" name="activo" id="activo"
                <?php echo e(old('activo') == null
                    ? (isset($perfil) && $perfil->activo == 0
                        ? ''
                        : 'checked')
                    : (old('activo') == 1
                        ? 'checked'
                        : '')); ?>>

            <label class="form-check-label" for="flexCheckDefault">
                Activo
            </label>
        </div>


        <div class="d-flex justify-content-end py-2">
            <button type="submit" class="btn btn-primary" style="margin-right: 20px;">Guardar</button>
            <button class="btn btn-danger data-dismiss=">Cancelar</button>
        </div>
    </form>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\CORE I5\Desktop\uta\webProyecto4\proyecto4\sistema-alarmas-web\resources\views/perfiles/guardar.blade.php ENDPATH**/ ?>