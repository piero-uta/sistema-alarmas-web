<?php $__env->startSection('title', 'Red de Aviso'); ?>

<?php $__env->startPush('head-scripts'); ?>
    
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

    <h2>Red de aviso</h2>
    

    
    <form method="GET" class="form form__container" action="<?php echo e(route('red-avisos.index')); ?>">
        <div class="form-group">
            <label for="direccion">Dirección</label>
            <select class="form-control" id="direccion" name="direccion_id">
                <option value="">Seleccionar</option>
                <?php $__currentLoopData = $direcciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $direccion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                    <option value="<?php echo e($direccion->id); ?>"
                        <?php echo e(old('direccion_id') == null
                            ? (isset($direccion_id) && $direccion_id == $direccion->id
                                ? 'selected'
                                : '')
                            : (old('direccion_id') == $direccion->id
                                ? 'selected'
                                : '')); ?>>
                        <?php echo e($direccion->codigo); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <button type="submit" class="btn btn-primary">Seleccionar</button>

    </form>

    <?php if($redes->count() > 0): ?>
        <div id="map" style="height: 400px; width: 100%; z-index: 0; margin: 3rem 0"></div>



        <table class="table">
            <thead>
                <tr>
                    <th scope="col">
                        #
                    </th>
                    <th scope="col">
                        Código de dirección aviso
                    </th>
                    <th scope="col">
                        Activo
                    </th>
                    <th scope="col">
                        Acción
                    </th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $redes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $red): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php ($direccion_red = $direcciones->where('id', $red->direccion_vecino_id)->first()); ?>
                    <tr>
                        <th scope="row">
                            <?php echo e($red->id); ?>

                        </th>
                        <td>
                            
                            <?php echo e($direccion_red->codigo); ?>

                        </td>
                        <td>
                            <?php if($red->activo): ?>
                                Activo
                            <?php else: ?>
                                Inactivo
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if(in_array('RedAviso-u', $permisos)): ?>
                                <form method="GET" class="form form__container"
                                    action="<?php echo e(route('red-avisos.crearEditar')); ?>">
                                    <input type="hidden" name="direccion_id" value="<?php echo e($direccion_id); ?>" required>
                                    <input type="hidden" name="id" value="<?php echo e($red->id); ?>" required>
                                    <button type="submit" class="btn btn-primary">Editar</button>
                                </form>
                            <?php endif; ?>
                            <?php if(in_array('RedAviso-d', $permisos)): ?>
                                <form method="POST" action="<?php echo e(route('red-avisos.eliminar')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="direccion_id" value="<?php echo e($direccion_id); ?>" required>
                                    <input type="hidden" name="id" value="<?php echo e($red->id); ?>" required>
                                    <button type="submit" class="btn btn-danger">Eliminar</button>
                                </form>
                            <?php endif; ?>
                        </td>

                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

    <?php endif; ?>
    <?php if(in_array('RedAviso-c', $permisos)): ?>
        <?php if($direccion_id != ''): ?>
            
            <form method="GET" class="form form__container" action="<?php echo e(route('red-avisos.crearEditar')); ?>">
                <input type="hidden" name="direccion_id" value="<?php echo e($direccion_id); ?>" required>
                <button type="submit" class="btn btn-primary">Crear</button>
            </form>
        <?php else: ?>
            <h3>Debes seleccionar una dirección</h3>
        <?php endif; ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    const direccion_id = <?php echo $direccion_id; ?>;
    const redes = <?php echo json_encode($redes); ?>;
    const direcciones = <?php echo json_encode($direcciones); ?>;
    const comunidad = <?php echo json_encode($comunidad); ?>;
</script>
<script type="text/javascript" src="<?php echo e(asset('js/redAviso/indexMapa.js')); ?>"></script>
<script async defer
        src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCJNN-iTg6exmzgXLjB_4KNGY_869oNBGM&v=beta&libraries=marker&callback=initMap">
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\CORE I5\Desktop\uta\webProyecto4\proyecto4\sistema-alarmas-web\resources\views/redAviso/index.blade.php ENDPATH**/ ?>