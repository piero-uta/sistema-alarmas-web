<?php $__env->startSection('title', 'Guardar usuario'); ?>

<?php $__env->startSection('content'); ?>
    <h2>Crear usuario</h2>
    <form method="POST" action="<?php echo e(route('usuarios.handleGuardar')); ?>">
        <?php echo csrf_field(); ?>
        <?php if(isset($usuario)): ?>
            <input type="hidden" name="id" value="<?php echo e($usuario->id); ?>">
        <?php endif; ?>

        <div class="form-group">
            <label for="nombre" class="label">Nombre*</label>
            <input type="text" class="form-control" name="nombre" required
                value="<?php echo e(old('nombre') == null ? (isset($usuario) ? $usuario->nombre : '') : old('name')); ?>">
        </div>
        <div class="form-group">
            <label for="apellido_paterno" class="label">Apellido paterno*</label>
            <input type="text" class="form-control" name="apellido_paterno" required
                value="<?php echo e(old('apellido_paterno') == null ? (isset($usuario) ? $usuario->apellido_paterno : '') : old('apellido_paterno')); ?>">
        </div>
        <div class="form-group">
            <label for="apellido_materno" class="label">Apellido materno</label>
            <input type="text" class="form-control" name="apellido_materno"
                value="<?php echo e(old('apellido_materno') == null ? (isset($usuario) ? $usuario->apellido_materno : '') : old('apellido_materno')); ?>">
        </div>
        <div class="form-group">
            <label for="email" class="label">Email*</label>
            <input type="email" class="form-control" name="email" required
                value="<?php echo e(old('email') == null ? (isset($usuario) ? $usuario->email : '') : old('email')); ?>">
        </div>
        <div class="form-group">
            <label for="password" class="label">Password*</label>
            <input type="password" class="form-control" name="password" required>
        </div>

        
        <div class="input-group">
            <div class="input-group-prepend">
                <label class="input-group-text" for="direccion_id">Direccion</label>
            </div>
            <select class="custom-select" name="direccion_id">
                <option value="">Seleccionar</option>
                <?php $__currentLoopData = $direcciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $direccion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($direccion->id); ?>"
                        <?php echo e(old('direccion_id') == null
                            ? (isset($usuario) && $direccion_id == $direccion->id
                                ? 'selected'
                                : '')
                            : (old('direccion_id') == $direccion->id
                                ? 'selected'
                                : '')); ?>>
                        <?php echo e($direccion->calle); ?> <?php echo e($direccion->numero); ?> <?php echo e($direccion->piso); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <hr>

        <div class="input-group">
            <div class="input-group-prepend">
                <label class="input-group-text" for="perfil_id">Perfil</label>
            </div>
            <select class="custom-select" name="perfil_id">
                <option value="">Seleccionar</option>
                <?php $__currentLoopData = $perfiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perfil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($perfil->id); ?>"
                        <?php echo e(old('perfil_id') == null
                            ? (isset($usuario) && $perfil_id == $perfil->id
                                ? 'selected'
                                : '')
                            : (old('perfil_id') == $perfil->id
                                ? 'selected'
                                : '')); ?>>
                        <?php echo e($perfil->nombre); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>


        <div class="form-check py-2">
            <input class="form-check-input" type="checkbox" name="activo" id="activo"
                <?php echo e(old('activo') == null
                    ? (isset($usuario) && $usuario->activo == 0
                        ? ''
                        : 'checked')
                    : (old('activo') == 1
                        ? 'checked'
                        : '')); ?>>

            <label class="form-check-label" for="flexCheckDefault">
                Activo
            </label>
        </div>


        <div class="d-flex justify-content-end py-2">
            <button type="submit" class="btn btn-primary" style="margin-right: 20px;">Guardar</button>
            <button class="btn btn-danger data-dismiss=">Cancelar</button>
        </div>
    </form>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\CORE I5\Desktop\uta\webProyecto4\proyecto4\sistema-alarmas-web\resources\views/usuarios/guardar.blade.php ENDPATH**/ ?>