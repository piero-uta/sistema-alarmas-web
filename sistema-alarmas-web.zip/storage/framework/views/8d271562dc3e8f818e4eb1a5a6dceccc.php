<?php $__env->startSection('title', 'Perfiles'); ?>

<?php $__env->startSection('content'); ?>
    <h2>Perfiles</h2>
    

    <div class="table-responsive">
        <table id="myTable" class="display" width="100%" cellspacing="0">
            <thead>
                <tr>
                    <th scope="col">
                        #
                    </th>
                    <th scope="col">
                        Perfil
                    </th>
                    <th scope="col">
                        Estado
                    </th>
                    <th scope="col">
                        Acciones
                    </th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $perfiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perfil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row">
                            <?php echo e($perfil->id); ?>

                        </th>
                        <td>
                            <?php echo e($perfil->nombre); ?>

                        </td>
                        <td>
                            <?php if($perfil->activo): ?>
                                Activo
                            <?php else: ?>
                                Inactivo
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="d-flex">
                                
                                
                                
                                <?php if(in_array('Perfiles-u', $permisos)): ?>
                                    <a href="<?php echo e(route('perfiles.crearEditar')); ?>?id=<?php echo e($perfil->id); ?>" type="button"
                                        class="btn btn-primary" style="margin-right: 20px;">Editar</a>
                                <?php endif; ?>
                                
                                <?php if(in_array('Perfiles-d', $permisos)): ?>
                                    <form method="POST" action="<?php echo e(route('perfiles.eliminar')); ?>">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="id" value=<?php echo e($perfil->id); ?>>
                                        <button type="submit" class="btn btn-danger">Eliminar</button>
                                    </form>
                                <?php endif; ?>
                        </td>
    </div>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </tbody>

    </table>
    </div>
    <?php if(in_array('Perfiles-c', $permisos)): ?>
        <div class="d-flex justify-content-end py-2">
            <a href="<?php echo e(route('perfiles.crearEditar')); ?>" type="button" class="btn btn-primary">Crear</a>
        </div>
    <?php endif; ?>




    
    <div class="modal" tabindex="-1" id="modalUsuario">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Usuario</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body"></div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>

                    <a type="button" class="btn btn-primary" href="#" id="btn_editar_usuario">Editar</a>

                    <form action="#" method="POST" id="form_eliminar_usuario">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id" id="id_usuario_eliminar" required>
                        <button type="submit" class="btn btn-danger" id="btn_eliminar_usuario">Eliminar</button>
                    </form>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    

    <script>
        var table = new DataTable('#myTable', {
            language: {
                url: '//cdn.datatables.net/plug-ins/1.13.6/i18n/es-ES.json',
            },
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\CORE I5\Desktop\uta\webProyecto4\proyecto4\sistema-alarmas-web\resources\views/perfiles/index.blade.php ENDPATH**/ ?>