<?php $__env->startSection('title', 'Comunidades'); ?>

<?php $__env->startSection('content'); ?>

    <h2>Comunidades</h2>
    

    <div class="table-responsive">
        <table id="myTable" class="display" width="100%" ellspacing="0">
            <thead>
                <tr>
                    <th scope="col">
                        #
                    </th>
                    <th scope="col">
                        Rut
                    </th>
                    <th scope="col">
                        Razon social
                    </th>
                    <th scope="col">
                        Dirección
                    </th>
                    <th scope="col">
                        Tipo servicio
                    </th>
                    <th scope="col">
                        Costo mensual
                    </th>
                    <th scope="col">
                        Estado
                    </th>
                    <th scope="col">
                        Acciones
                    </th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $comunidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comunidad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row">
                            <?php echo e($comunidad->id); ?>

                        </th>
                        <td>
                            <?php echo e($comunidad->rut); ?>-<?php echo e($comunidad->digito); ?>

                        </td>
                        <td>
                            <?php echo e($comunidad->razon_social); ?>

                        </td>
                        <td>
                            <?php echo e($comunidad->direccion); ?>

                        </td>
                        <td>
                            <?php echo e($comunidad->tipo_servicio); ?>

                        </td>
                        <td>
                            <?php echo e($comunidad->costo_mensual); ?>

                        </td>
                        <td>
                            <?php if($comunidad->activo): ?>
                                Activo
                            <?php else: ?>
                                Inactivo
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="d-flex">
                                <?php if(in_array('Comunidad-r', $permisos)): ?>
                                    <button type="button" class="btn btn-primary" style="margin-right: 20px;"
                                        onClick="modalComunidad(<?php echo e($comunidad); ?>)">Ver</button>
                                <?php endif; ?>
                                
                                <?php if(in_array('Comunidad-u', $permisos)): ?>
                                    <a type="button" class="btn btn-primary"style="margin-right: 20px;"
                                        href="<?php echo e(route('comunidades.crearEditar')); ?>?id=<?php echo e($comunidad->id); ?>">Editar</a>
                                <?php endif; ?>
                                
                                <?php if(in_array('Comunidad-d', $permisos)): ?>
                                    <form method="POST" action="<?php echo e(route('comunidades.eliminar')); ?>">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="id" value="<?php echo e($comunidad->id); ?>">
                                        <button type="submit" class="btn btn-danger">Eliminar</button>
                                    </form>
                                <?php endif; ?>
                            </div>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>

        </table>
        <?php if(in_array('Comunidad-c', $permisos)): ?>
            <div class="d-flex justify-content-end py-2">
                <a type="button" class="btn btn-primary" href="<?php echo e(route('comunidades.crearEditar')); ?>">Crear</a>
            </div>
        <?php endif; ?>
    </div>


    <div class="modal" tabindex="-1" id="modalComunidad">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Comunidad</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body"></div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                    
                    <a type="button" class="btn btn-primary" href="#" id="btn_editar_comunidad">Editar</a>
                    
                    <a type="button" class="btn btn-primary" href="#" id="btn_editar_comunidad">Gestionar
                        comunidad</a>
                    
                    <form action="#" method="POST" id="form_eliminar_comunidad">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id" id="id_comunidad_eliminar" required>
                        <button type="submit" class="btn btn-danger" id="btn_eliminar_comunidad">Eliminar</button>
                    </form>

                </div>
            </div>
        </div>
    </div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        function modalComunidad(comunidad) {
            const modal = new bootstrap.Modal(document.getElementById('modalComunidad'));
            modal.show();
            document.getElementById('modalComunidad').querySelector('.modal-body').innerHTML = `
            <p><strong>Rut:</strong> ${comunidad.rut}-${comunidad.digito}</p>
            <p><strong>Estado:</strong> ${comunidad.activo ? 'Activo' : 'Inactivo'}</p>
            <p><strong>Razon social:</strong> ${comunidad.razon_social?comunidad.razon_social:''}</p>
            <p><strong>Representante legal:</strong> ${comunidad.representante_legal?comunidad.representante_legal:''}</p>
            <p><strong>Email:</strong> ${comunidad.email?comunidad.email:''}</p>
            <p><strong>Dirección:</strong> ${comunidad.direccion?comunidad.direccion:''}</p>
            <p><strong>Giro:</strong> ${comunidad.giro?comunidad.giro:''}</p>
            <p><strong>Tipo servicio:</strong> ${comunidad.tipo_servicio?comunidad.tipo_servicio:''}</p>
            <p><strong>Costo mensual:</strong> ${comunidad.costo_mensual?comunidad.costo_mensual:''}</p>
            <p><strong>Telefono:</strong> ${comunidad.telefono?comunidad.telefono:''}</p>
            <p><strong>Celular:</strong> ${comunidad.celular?comunidad.celular:''}</p>



        `;
            document.getElementById('btn_editar_comunidad').href = "<?php echo e(route('comunidades.crearEditar')); ?>?id=" + comunidad
                .id;

            document.getElementById('form_eliminar_comunidad').action = "<?php echo e(route('comunidades.eliminar')); ?>";
            document.getElementById('id_comunidad_eliminar').value = comunidad.id;

        }
    </script>
    <script>
        var table = new DataTable('#myTable', {
            language: {
                url: '//cdn.datatables.net/plug-ins/1.13.6/i18n/es-ES.json',
            },
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\CORE I5\Desktop\uta\webProyecto4\proyecto4\sistema-alarmas-web\resources\views/comunidades/index.blade.php ENDPATH**/ ?>