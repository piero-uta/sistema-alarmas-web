<?php $__env->startSection('title', 'AsignacionPerfiles'); ?>

<?php $__env->startSection('content'); ?>
    <h2>Asignacion de Perfiles</h2>
    
    <hr>
    <label>selección Perfiles: </label>
    <select id="redireccionarSelect">
        <?php $__currentLoopData = $perfiles_comunidad; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perfil_comunidad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value=<?php echo e($perfil_comunidad->id); ?> <?php if($perfil_comunidad->id == $perfil_aux): ?> selected <?php endif; ?>>
                <?php echo e($perfil_comunidad->nombre); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <hr>

    <div class="table-responsive">
        
        <table id="myTable" class="display" width="100%" cellspacing="0">
            <thead>
                <tr>
                    <th scope="col">
                        #
                    </th>
                    <th scope="col">
                        Menú
                    </th>
                    <th scope="col">
                        Acciones
                    </th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $todasLasOpciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permiso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row">
                        </th>
                        <td>
                            <?php echo e($permiso['opcion']); ?>

                        </td>
                        <td>
                            <?php
                                $array = explode('-', $permiso['acciones_concatenadas']);
                            ?>
                            <?php $__currentLoopData = ['c' => 'Crear', 'r' => 'Leer', 'u' => 'Actualizar', 'd' => 'Eliminar']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $letter => $action): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(in_array($letter, $array)): ?>
                                    
                                    <input type="checkbox" class="checkbox-perfiles"
                                        name="<?php echo e($perfil_aux . '-' . $permiso['opcion'] . '-' . $letter); ?>"
                                        value="<?php echo e($letter); ?>" checked>
                                <?php else: ?>
                                    
                                    <input type="checkbox" class="checkbox-perfiles"
                                        name="<?php echo e($perfil_aux . '-' . $permiso['opcion'] . '-' . $letter); ?>"
                                        value="<?php echo e($letter); ?>">
                                <?php endif; ?>
                                <?php echo e($action); ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
    </div>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>

    </table>
    </div>



    
    <div class="modal" tabindex="-1" id="modalUsuario">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Usuario</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body"></div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>

                    <a type="button" class="btn btn-primary" href="#" id="btn_editar_usuario">Editar</a>

                    <form action="#" method="POST" id="form_eliminar_usuario">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id" id="id_usuario_eliminar" required>
                        <button type="submit" class="btn btn-danger" id="btn_eliminar_usuario">Eliminar</button>
                    </form>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        var table = new DataTable('#myTable', {
            language: {
                url: '//cdn.datatables.net/plug-ins/1.13.6/i18n/es-ES.json',
            },
        });
    </script>
    <script type="text/javascript">
        // Obtén una referencia al elemento <select>
        var select = document.getElementById("redireccionarSelect");

        // Agrega un evento onchange al elemento <select>
        select.addEventListener("change", function() {
            // Obtiene el valor seleccionado
            var selectedValue = select.value;




            // Verifica que el valor no esté vacío
            if (selectedValue) {
                // Redirige a la URL seleccionada
                var url = `/asignacionPerfiles/${selectedValue}`;
                window.location.href = url;
            }
        });
    </script>
    <script>
        $(document).ready(function() {
            $('.checkbox-perfiles').change(function() {
                // Obtener el atributo "name" del checkbox
                var checkboxName = $(this).attr('name');

                // Hacer una solicitud AJAX cuando cambia el estado del checkbox
                var isChecked = $(this).is(':checked');
                $.ajax({
                    url: '<?php echo e(route('asignacionPerfiles.onCheckedPermiso')); ?>', // La URL de la ruta en Laravel
                    type: 'POST', // Puedes cambiar el método HTTP según tus necesidades
                    data: {
                        _token: '<?php echo e(csrf_token()); ?>', // Agregar el token CSRF
                        checkboxName: checkboxName, // Enviar el atributo "name" del checkbox
                        isChecked: isChecked, // Enviar el estado del checkbox (marcado o desmarcado)
                        // Otra información que desees enviar al controlador
                    },
                    success: function(response) {
                        console.log(response);
                        // Maneja la respuesta del controlador aquí
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\CORE I5\Desktop\uta\webProyecto4\proyecto4\sistema-alarmas-web\resources\views/asignacionPerfiles/index.blade.php ENDPATH**/ ?>