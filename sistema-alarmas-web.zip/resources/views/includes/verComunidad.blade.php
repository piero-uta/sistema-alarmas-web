<a class="btn nav-link" href="/comunidades/ver" >Comunidad seleccionada: {{ session('comunidad_id') }}</a>


