@extends('layouts.app')
@section('title', 'Dashboard')

@section('content')
<h1>En construcción</h1>

@endsection